/**
 * ExcesoChoferException.java
 * Clase que implementa escepcion para cuando no se pueda guardar a otro chofer
 */
public class ExcesoChoferException extends Exception{

	public ExcesoChoferException(String message){
		super(message);
	}

}
